/*!
 * \file interrupts.h
 * \author Pavel Schal
 * \version 1.0
 * \date 17.11.2020
 * \warning Die Datei interrupts.h v_1.0 wurde noch nicht getestet.
 * \brief Interrupts Funktionen.
 *
 * Diese Datei beinhaltet die Interrupts.
 *
 * \attention Das .h/.c Modul kann frei und ohne Lizenz verwendet werden. Nur der erste Doxigen-Block in
 * 			  jeder Datei soll bleiben.
*/
/**/
#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_
/**/

/**/
#endif /* INTERRUPTS_H_ */
