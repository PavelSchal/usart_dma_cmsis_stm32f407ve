/*!
 * \file main.h
 * \author Pavel Schal
 * \version 1.0
 * \date 17.11.2020
 * \warning Die Datei main.h v_1.0 wurde noch nicht getestet.
 * \brief SPI Modul in DMA Modus.
 *
 * Main Datei mit main() Funktion.
 *
 * \attention Das .h/.c Modul kann frei und ohne Lizenz verwendet werden. Nur der erste Doxigen-Block in
 * 			  jeder Datei soll bleiben.
*/
/**/
#ifndef MAIN_H_
#define MAIN_H_
/**/
#include "stm32f4xx.h"
#include "system_stm32f4xx.h"
#include "stdint.h"
/**/
#include "SysClock.h"	/* own Datei */
#include "gpio.h"		/* own Datei */
#include "usart.h"		/* own Datei */
#include "dma.h"		/* own Datei */
#include "interrupts.h"	/* own Datei */
/**/
extern __IO uint32_t tmpreg ;
/**/
#endif /* MCU_CLOCK_INIT_H_ */
