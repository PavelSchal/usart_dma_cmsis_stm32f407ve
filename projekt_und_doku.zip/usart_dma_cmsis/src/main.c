/*!
 * \file main.c
 * \author Pavel Schal
 * \version 1.0
 * \date 17.11.2020
 * \warning Die Datei main.c v_1.0 wurde noch nicht getestet.
 * \brief Entry point ist main( ) Funktion.
 *
 * Diese Datei beinhaltet Sende- Empangsfunktionen im usart dma Modus als Beispiel.
 *
 * \attention Das .h/.c Modul kann frei und ohne Lizenz verwendet werden. Nur der erste Doxigen-Block in
 * 			  jeder Datei soll bleiben.
*/
/**/
#include <stdio.h>
#include <stdlib.h>
#include "diag/Trace.h"
/**/
#include "main.h"
/**/
// Sample pragmas to cope with warnings. Please note the related line at
// the end of this function, used to pop the compiler diagnostics status.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wmissing-declarations"
#pragma GCC diagnostic ignored "-Wreturn-type"
/**/
__IO uint32_t tmpreg = 0x00 ;	/* Temporaelle Variable, um klein "delay" zu realisieren. extern. */
/**/
uint8_t testBuffTx[ 10 ] = "0123456789" ;
uint8_t testBuffRx[ 10 ] = { 0x00 } ;
/**/
int main( int argc, char* argv[ ] ) {
	/**/
	SystemInit( ) ; 	/* cmsis: systeminitialisation */
	SysClockInit( ) ;	/* own: MCU clock initialisation */
	GpioInit( ) ;		/* own: GPIO initialisation */
	DmaInit( ) ;		/* own: DMA Initialisation */
	UsartInit( ) ;		/* own: USART Initialisation */
	/**/
	while( 1 ) {
		UsartDmaTx( testBuffTx, 10 ) ;									/* 10 Bytes werden ueber usart dma gesendet */
		for( uint32_t i = 0x00 ; i < 100000 ; i ++ ) asm( "NOP\n\t" ) ;	/* delay */
		UsartDmaRx( testBuffRx, 10 ) ;									/* 10 Bytes werden ueber usart dma empfangen */
		for( uint32_t i = 0x00 ; i < 100000 ; i ++ ) asm( "NOP\n\t" ) ; /* delay */
	}
}
/**/
#pragma GCC diagnostic pop
